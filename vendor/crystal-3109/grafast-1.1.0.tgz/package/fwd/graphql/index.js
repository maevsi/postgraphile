module.exports = require("graphql");
